# CCSDS Randomization Chall

## Description
We have captured an old satellite system which uses legacy CCSDS randomizaion for RF communication scrambling. Can you descramble this satellite communication?

## After Solving it
After solving the challenge, please return to the Aerospace Village GMO booth to receive a small gift.
