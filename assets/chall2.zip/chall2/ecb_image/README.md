# Satellite ECB Encryption

## Description
I covertly intercepted a satellite’s CADU packets and saved them in packet.pcap. I believe the payload is encrypted with AES‑128 in ECB mode. Can you decrypt these packets?

hint:
```bash
$ file flag.bmp
PC bitmap, Windows 3.x format, 1536 x 1024 x 24, image size 4718592, resolution 2925 x 2925 px/m, cbSize 4718646, bits offset 54
```

## After Solving it
After solving the challenge, please return to the Aerospace Village GMO booth to receive a small gift.
